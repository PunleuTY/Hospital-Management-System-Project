import express from "express";
import { success, error } from "../utils/response.js";
export const getAllbills = async (req, res) => {};
export const getBillById = async (req, res) => {};
export const createBill = async (req, res) => {};
export const updateBill = async (req, res) => {};
export const deleteBill = async (req, res) => {};
