import express from "express";
import { success, error } from "../utils/response.js";

export const getAllStaff = async (req, res) => {};
export const getStaffById = async (req, res) => {};
export const createStaff = async (req, res) => {};
export const updateStaff = async (req, res) => {};
export const deleteStaff = async (req, res) => {};
