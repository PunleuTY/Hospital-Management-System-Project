import Appointment from "../models/appointment.js";
import express from "express";
export const getAllMedicalRecords = async (req, res) => {};
export const getMedicalRecordById = async (req, res) => {};
export const createMedicalRecord = async (req, res) => {};
export const updateMedicalRecord = async (req, res) => {};
export const deleteMedicalRecord = async (req, res) => {};
