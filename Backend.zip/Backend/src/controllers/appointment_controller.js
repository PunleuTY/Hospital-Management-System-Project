import Appointment from "../models/appointment.js";
import express from "express";
import { success, error } from "../utils/response.js";

export const getAllAppointments = async (req, res) => {};
export const getAppointmentById = async (req, res) => {};
export const createAppointment = async (req, res) => {};
export const updateAppointment = async (req, res) => {};
export const deleteAppointment = async (req, res) => {};
